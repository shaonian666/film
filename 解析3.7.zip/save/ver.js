﻿document.writeln("<font color=\'#ff0000\'>3.7版本</font>");
