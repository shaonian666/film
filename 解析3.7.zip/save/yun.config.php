<?php
$API_URL=array (
  0 => 'http://api.iokzy.com/inc/apickm3u8.php',
  1 => 'http://www.zdziyuan.com/inc/s_api_zuidam3u8.php',
);
