<?php


$ERROR_404='404|404错误：你访问的页面丢失了|那条视频不见了|出错提示|404页';  

//输出类型转换,支持正则,格式： 正则(匹配播放源或URL) => 输出类型
$type_match=array(

'!m3u8!i'=>'hls',
'!\/share\/!i'=>'url',
);

//视频标题过滤
$title_replace= array("全集","高清在线观看","英语版",'英文版',"国语版","原声版","普通话版","《","》","【","】","（","）","(",")");

/* PHP正则简单语法(具体参考百度)
1.格式： /正则内容/i' , 其中，'/'为界定符,可以为任意成对字符，比如{}; 符号'i'标示匹配时不区分大小。
2.语法： ^ 匹配文本开头，$ 匹配文本结尾; \ 转义符,表示下个字符作普通文本处理 ; (表达式) 子表达式匹配文本; .*? 任意不包括换行符的字符; (?:表达式) 使用表达式,不获取匹配 ;
//目前各大视频站标题例子
1.腾讯	网页标题：创业时代 第01集_1080P在线观看平台_腾讯视频  
2.爱奇艺,芒果TV,搜狐,PPTV   网页标题：永远一家人 第13集 - 视频在线观看 - 永远一家人 - 芒果TV  
3.优酷	 网页标题：永远一家人 24—电视剧—视频高清在线观看-优酷
4.乐视，土豆        网页标题： 北京爱情故事01 - 在线观看 - 电视剧 - 乐视视频
5.B站动漫       网页标题： 嫁给非人类：第5话_番剧_bilibili_哔哩哔哩 
6.咪咕视频         网页标题：《为青春点赞》第02集-高清正版在线播放-咪咕视频
7.风行视频   网页标题： 我们的四十年-第4集-电视剧-全集在线观看-风行网

 */
 
 //视频标题获取的规则设置,请勿随意修改,否则出错！
  $title_match=array(
      
       //爱奇艺     
       '!iqiyi.com!i'=>array('{.*?(?:qy-player-title|video-title)[\s\S]*?(<h1[\s\S]*?</h1>)}i'),  
       //优酷
      '!youku.com!i'=>array('{.*?title-wrap[\s\S]*?(<h1[\s\S]*?</h1>)}i'),      
       //腾讯     
       '!qq.com!i'=>array('{.*?video_base _base[\s\S]*?(<h1[\s\S]*?</h1>)}i'),  
      //芒果TV
       '!mgtv.com!i'=>array('{.*?(?:player-box|video-area-bar)[\s\S]*?(<h1[\s\S]*?</h1>)}i'), 
       //乐视
       '!le.com!i'=>array('{.*?briefIntro_tit[\s\S]*?(<a[\s\S]*?</a>)}i','{.*?column_box[\s\S]*?(<h2[\s\S]*?</h2>)}i'),      
       //搜狐
       '!sohu.com!i'=>array('{.*?video-sort[\s\S]*?</span>([\s\S]*?)</h2>}i'), 
      //pptv
       '!pptv.com!i'=>array('{.*?video-info[\s\S]*?(<h1[\s\S]*?</h1>)}i'),  
     //土豆
       '!tudou.com!i'=>array('{.*?td-playbase__info[\s\S]*?(<h1[\s\S]*?</h1>)}i','{.*?play-video-desc[\s\S]*?(<div[\s\S]*?</div>)}i'),  
      //bilibili.com
        '!bilibili.com!i'=>array('{.*?media-wrapper[\s\S]*?(<h1[\s\S]*?</h1>)}i','{.*?ep-info-center[\s\S]*?(<div[\s\S]*?</div>)}i'), 
      //虎牙
         '!huya.com!i'=>array('{.*?video-detail[\s\S]*?(<h2[\s\S]*?</h2>)}i','{.*?video-title-new-t[\s\S]*?(<h1[\s\S]*?</h1>)}i'),
      //斗鱼,咪咕视频
         '!douyu.com|miguvideo.com!i'=>array('{.*?video-title[\s\S]*?(<h1[\s\S]*?</h1>)}i','{.*?video-describe[\s\S]*?(<div[\s\S]*?</div>)}i'),     
      //通用
	'!^.*$!i'=>array('{<title.*?>(.*?)(?:-|—|_|——|-).*?</title>}i'),            
 );


 //视频名称和集数获取的规则设置,请勿随意修改,否则出错！(匹配规则：子表达式1为标题,子表达式2为集数)
 $name_match=array(     
   
     //腾讯视频
	'!qq.com!i'=>array('{^(?:《|)(.*?)(?:》|)(?:第|)(\d+)(?=话|集|期).*?}i'),   

    //乐视，土豆  
	 '!le.com|tudou.com!i'=>array('/^(.*?)(\d+)/i'),                              
    //B站番剧
	 '!bilibili.com!i'=>array('/^(.*?)：(?:第|)(\d+)(?=话|集)/i'),                             
    //咪咕视频
	 '!miguvideo.com!i'=>array('/^(?:《|)(.*?)(?:》|)(?:第|)(\d+)(?=话|集)/i'),   	
      //通用
	'!^.*$!i'=>array('{^(.*?)\s*(?:：|:|\s)[\s\S]*?(?:第|)(\d+)(?:话|集|期)}i','{《(.*?)》.*?}','{^(.*?)\s*(?:：|:|\s)}i','{^(.*?)(?:第|)(\d+)(?:集|期|话|)$}i','/^(.*?)$/i'),    
 );	
 
//URL地址过滤
  $url_replace= array("&tdsourcetag=s_pcqq_aiomsg");
 
//视频地址转换,使用PHP正则,规则：'=>'后面的'(?n)'会用前面正则左起第n个小括号里的匹配内容替换。

  $url_match=array(
    '!m.v.qq.com.*?cid=(.*?)&vid=(.*?)[?:&|$]!i'=>'https://v.qq.com/x/cover/(?1)/(?2).html',
	'!m.v.qq.com.*?cid=(.*?)[?:&|$]!i'=>'https://v.qq.com/x/cover/(?1).html',
	'!m.v.qq.com/cover/r/(.*?)cid=(.*?)[?:&|$]!i'=>'https://v.qq.com/x/cover/(?1).html',
	'!m.v.qq.com/cover/./(.*?)\.html\?vid=(.*?)(?:&|$)!i'=>'https://v.qq.com/x/cover/(?1)/(?2).html',
	'!m.fun.tv/mplay/\?mid=(\d+)&vid=(\d+)(?:&|$)!i'=>'https://www.fun.tv/vplay/g-(?1).v-(?2)',
	'!http://(.*?mgtv.com/.*?html)!i'=>'https://(?1)',
	'!m.youku.com/video/id_(.*?)==.html!i'=>'https://v.youku.com/v_show/id_(?1)==.html',
        '!m.bilibili.com/(.*?)!i'=>'https://www.bilibili.com/(?1)',

 );
