<?php 


// 检测PHP环境
if(version_compare(PHP_VERSION,'5.4.0','<')){die('PHP版本过低，最少需要PHP5.6，请升级PHP版本！');}

//运行目录
define("FCPATH", str_replace("\\", "/",dirname(__FILE__)));

//加载配置文件
require_once FCPATH.'/save/config.php';

define("ROOT_PATH", $ROOT_PATH ? $ROOT_PATH:GlobalBase::is_root());

//加载防火墙规则
Blacklist::parse($BLACKLIST);

//广告过滤
if(filter_input(INPUT_GET, $BLACKLIST["adblack"]["name"])){exit(AdBlack::parse($BLACKLIST["adblack"],ROOT_PATH));}


///空参数处理
if($NULL_URL['type']>0 && !filter_input(INPUT_GET, "url")&& !filter_input(INPUT_GET, "v")&&!filter_input(INPUT_GET, "wd")){
		    if($NULL_URL['type']==1){
			  exit(base64_decode($NULL_URL['info']));
		  }else if($NULL_URL['type']==2){
   $NULL_JMP=$NULL_URL['url']; 
$code=base64_decode($FOOTER_CODE);
exit(<<<code
<!DOCTYPE html>
 <!--[if lt IE 7 ]><html class=ie6><![endif]--> <!--[if IE 7 ]><html class=ie7><![endif]--> <!--[if IE 8 ]><html class=ie8><![endif]--> <!--[if IE 9 ]><html class=ie9><![endif]--> <!--[if (gt IE 9)|!(IE)]><!--><html class=w3c><!--<![endif]-->       
<html><head>     
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" /> <meta name="renderer" content="webkit" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
<meta http-equiv="pragma" content="no-cache" /><meta http-equiv="expires" content="0" />
<meta name="keywords" content="$keywords" />
<meta name="description" content="$description" />   
<title>$TITLE</title> 
<style>
html,body{overflow:hidden;  
width:100%;
height: 100%; 
margin: 0;
padding: 0;
}
</style>
</head>
<body>
<iframe width="100%" height="100%" src="$NULL_JMP" frameborder="0" border="0" marginwidth="0" marginheight="0" scrolling="no" ></iframe>
 $code       
</body>
</html>  	 
code
); 	
	  }
}

//v值转换
//$v=urldecode(filter_input(INPUT_GET, "v"));
//

//if($v && preg_match('/[\x{4e00}-\x{9fa5}]+/u',$v)){header("Refresh:0;url=".ROOT_PATH."?wd=".urlencode($v)); exit;}


//定义模板目录,请勿修改！
if(lsMobile())	{ define('TEMPLETS_PATH', 'templets/'.$templets['wap'].'/'); }else{define('TEMPLETS_PATH', 'templets/'.$templets['pc'].'/');}

include_once  TEMPLETS_PATH.$templets['html'].'/index.php';

