<?php require_once dirname(__FILE__)."/../include/class.main.php";include "data.php"; header("Content-type: text/html; charset=utf-8");
$ver='3.42';
$user='admin';
$pass='7fef6171469e80d32c0559f88b377245';
$TITLE='智能视频解析';
$keywords='vip视频解析,vip视频在线解析,vip解析,万能vip视频解析,vip视频全能解析,vip视频,手机vip视频解析,手机在线解析vip视频,优酷vip解析,爱奇艺vip解析,腾讯vip解析,乐视vip解析,芒果vip解析';
$description='xyplay解析VIP视频免费看，在线解析，vip视频解析，优酷vip解析，爱奇艺vip解析，腾讯vip解析，乐视vip解析，芒果vip解析方便广大用户VIP视频服务，最新电影最新电视剧在线免费观看';
$HEADER='PG1ldGEgaHR0cC1lcXVpdj0iQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luIiBjb250ZW50PSIqIj48IS0tIOWFgeiuuOi3qOWfn+iuv+mXriAtLT4KPG1ldGEgaHR0cC1lcXVpdj0icHJhZ21hIiBjb250ZW50PSJuby1jYWNoZSIgLz48bWV0YSBodHRwLWVxdWl2PSJleHBpcmVzIiBjb250ZW50PSIwIiAvPiAgICA8IS0tIOS4jee8k+WtmOe9kemhtSAtLT4KPG1ldGEgbmFtZT0ieDUtZnVsbHNjcmVlbiIgY29udGVudD0idHJ1ZSIgLz48bWV0YSBuYW1lPSJ4NS1wYWdlLW1vZGUiIGNvbnRlbnQ9ImFwcCIgIC8+IDwhLS0gWDUgIOWFqOWxj+WkhOeQhiAtLT4KPG1ldGEgbmFtZT0iZnVsbC1zY3JlZW4iIGNvbnRlbnQ9InllcyIgLz48bWV0YSBuYW1lPSJicm93c2VybW9kZSIgY29udGVudD0iYXBwbGljYXRpb24iIC8+ICA8IS0tIFVDIOWFqOWxj+W6lOeUqOaooeW8jyAtLT4KPG1ldGEgbmFtZT3igJ1hcHBsZS1tb2JpbGUtd2ViLWFwcC1jYXBhYmxl4oCdIGNvbnRlbnQ94oCdeWVz4oCdIC8+IDxtZXRhIG5hbWU94oCdYXBwbGUtbW9iaWxlLXdlYi1hcHAtc3RhdHVzLWJhci1zdHlsZeKAnSBjb250ZW50PeKAnWJsYWNrLXRyYW5zbHVjZW504oCdIC8+IDwhLS0gIOiLueaenOWFqOWxj+W6lOeUqOaooeW8jyAtLT4=';
$API_PATH='api.php';
$ROOT_PATH='';
$templets=array (
  'off' => '0',
  'html' => 'html',
  'css' => '',
  'pc' => 'byg',
  'wap' => 'byg',
);
$chche_config=array (
  'type' => '1',
  'prot' => '6379',
  'time' => '24h',
);
$BOOK_INFO=array (
  'off' => '0',
  'info' => 'PGZvbnQgY29sb3I9IiMwMEZGMDAiPuWmguaenOaSreaUvuWksei0pe+8jOivt+WIh+aNouS4jeWQjOe6v+i3ryHkupHmkq3mlL7lt7LmlK/mjIHnvJPlrZjnp5LliqDovb3vvIzmrKLov47kvb/nlKghPC9mb250Pg==',
);
$timecookie='2';
$timeout='5';
$from_timeout='5';
$BLACKLIST=array (
  'off' => '0',
  'match' => 
  array (
    0 => 
    array (
      'off' => '1',
      'type' => '0',
      'val' => 
      array (
        0 => 'mov.lunimei.vip',
      ),
      'black' => '0',
      'name' => '授权网站',
      'match' => '0',
      'num' => '100',
    ),
    1 => 
    array (
      'off' => '1',
      'type' => '1',
      'val' => 
      array (
        0 => 'av.com',
      ),
      'black' => '1',
      'name' => '视频黑名单',
      'match' => '1',
      'num' => '10',
    ),
    2 => 
    array (
      'off' => '0',
      'type' => '0',
      'val' => 
      array (
        0 => 'mov.lunimei.vip',
      ),
      'black' => '2',
      'name' => '域名黑名单',
      'match' => '1',
      'num' => '6',
    ),
    3 => 
    array (
      'off' => '0',
      'type' => '3',
      'val' => 
      array (
        0 => '127.0.0.1',
      ),
      'black' => '0',
      'name' => 'IP黑名单',
      'match' => '1',
      'num' => '100',
    ),
    4 => 
    array (
      'off' => '0',
      'type' => '2',
      'val' => 
      array (
        0 => 'xysoft',
      ),
      'black' => '0',
      'name' => '授权APP',
      'match' => '0',
      'num' => '110',
    ),
  ),
  'black' => 
  array (
    0 => 
    array (
      'type' => '1',
      'action' => '1',
      'info' => 'echo "本站已开启防盗链，获取授权请联系本站管理员";',
      'name' => '提示防盗链',
    ),
    1 => 
    array (
      'type' => '1',
      'action' => '1',
      'info' => 'echo "目标网站涉嫌非法信息,服务器已拒绝解析";',
      'name' => '提示非法信息',
    ),
    2 => 
    array (
      'type' => '1',
      'action' => '1',
      'info' => 'echo "目标网站在黑名单中,请联系网站管理员解除！";',
      'name' => '提示黑名单',
    ),
    3 => 
    array (
      'type' => '1',
      'action' => '1',
      'info' => 'echo "本站已开启防盗链，获取授权请联系本站管理员";
header("Refresh:3;url=http://lunimei.vip");',
      'name' => '跳转首页',
    ),
    4 => 
    array (
      'type' => '1',
      'action' => '1',
      'info' => 'header("HTTP/1.1 404 Not Found");exit("404,文件未找到");',
      'name' => '提示404',
    ),
    5 => 
    array (
      'type' => '0',
      'action' => '0',
      'info' => '<script> 
var _hmt = _hmt || [];
   (function() {
    var hm = document.createElement("script");
    hm.src = "https://hm.baidu.com/hm.js?dea6bad1057861a8f0ec2b6f8332eec1";
    var s = document.getElementsByTagName("script")[0]; 
    s.parentNode.insertBefore(hm,s);
})();
</script>',
      'name' => '植入广告',
    ),
  ),
  'adblack' => 
  array (
    'match' => 
    array (
      0 => 
      array (
        'off' => '1',
        'name' => '测试规则',
        'target' => '.*',
        'ref' => '',
        'num' => '100',
        'val' => 
        array (
          '点我测试' => '替换成功',
        ),
      ),
    ),
    'name' => 'jx',
  ),
  'type' => NULL,
);
$NULL_URL=array (
  'type' => '2',
  'url' => 'so.html',
  'info' => 'IDxzdHlsZSB0eXBlPSJ0ZXh0L2NzcyI+CiAgICBIMXttYXJnaW46MTAlIDAgYXV0bzsgY29sb3I6I0M3NjM2QzsgdGV4dC1hbGlnbjpjZW50ZXI7IGZvbnQtZmFtaWx5OiBNaWNyb3NvZnQgSmhlbmdoZWk7fQogICAgcHtmb250LXNpemU6IDEuMnJlbTsvKjEuMiDDlyAxMHB4ID0gMTJweCAqLzt0ZXh0LWFsaWduOmNlbnRlcjsgZm9udC1mYW1pbHk6IE1pY3Jvc29mdCBKaGVuZ2hlaTt9CiAgICA8L3N0eWxlPiAgCiAgIDxoMT7or7floavlhpl1cmzlnLDlnYA8L2gxPgogICA8cD7mnKzop6PmnpDmjqXlj6Pku4XnlKjkuo7lrabkuaDkuqTmtYHvvIznm5fnlKjlv4XnqbbvvIF+PC9wPg==',
);
$HEADER_CODE='';
$FOOTER_CODE='PHNjcmlwdD4gCnZhciBfaG10ID0gX2htdCB8fCBbXTsKICAgKGZ1bmN0aW9uKCkgewogICAgdmFyIGhtID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgic2NyaXB0Iik7CiAgICBobS5zcmMgPSAiaHR0cHM6Ly9obS5iYWlkdS5jb20vaG0uanM/ZGVhNmJhZDEwNTc4NjFhOGYwZWMyYjZmODMzMmVlYzEiOwogICAgdmFyIHMgPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5VGFnTmFtZSgic2NyaXB0IilbMF07IAogICAgcy5wYXJlbnROb2RlLmluc2VydEJlZm9yZShobSxzKTsKfSkoKTsKPC9zY3JpcHQ+';
$LINK_URL=array (
  0 => 
  array (
    'off' => '0',
    'type' => '1',
    'api' => '1',
    'match' => 'e1wkXC5wb3N0XCgiKC4rPykifQ==',
    'num' => '999',
    'name' => '官方CMS插件接口',
    'path' => 'http://mov.lunimei.vip/parse/api.php',
    'shell' => '',
    'html' => '',
    'fields' => 'IHVybD0kdXJs',
    'strtr' => 'JHVybA==',
    'cookie' => '',
    'proxy' => '',
    'val_off' => '0',
    'header' => NULL,
    'add' => NULL,
    'val' => NULL,
  ),
  1 => 
  array (
    'off' => '1',
    'type' => '0',
    'api' => '0',
    'match' => 'e1wkXC5wb3N0XCgiKC4rPykiLChcey4qXH0pLH0=',
    'num' => '100',
    'name' => '思古解析',
    'path' => 'https://api.azzc.cn/zy/?url=',
    'shell' => 'JHVybD1iYXNlNjRfZW5jb2RlKCR1cmwpOwoka2V5PSRfQ09PS0lFWydrZXknXTs=',
    'html' => 'PGh0bWw+CjxoZWFkPgo8c2NyaXB0IHR5cGU9InRleHQvamF2YXNjcmlwdCIgc3JjPSJodHRwczovL2Nkbi5ib290Y3NzLmNvbS9jcnlwdG8tanMvMy4xLjkvY3J5cHRvLWpzLmpzIj48L3NjcmlwdD4KPHNjcmlwdCB0eXBlPSJ0ZXh0L2phdmFzY3JpcHQiIHNyYz0iLi4vaW5jbHVkZS9jbGFzcy5jb29raWUuanMiPjwvc2NyaXB0Pgo8L2hlYWQ+Cjxib2R5Pgo8c2NyaXB0Pgp2YXIgX18weDJiYmNiID0gWydNUmZDaHc9PScsICdZMExEb01LU1FYUENvY09HJywgJ3dwZ1h3by9EaXNLV1lNT3BQUT09JywgJ3dwd013cGpEbThLUk04S3BmTUtSd3FIQ25UYkRnekxEbk1PYndwN0Rzc09CUXNLdXdwNVhFeFBDaFNOdkdWUmthY0svd3BERHFBNU8nLCAndzVFOUJzT0QnLCAnd3FURHM4T0x3NVFvJywgJ0Q4S0xjY0s2YkdoVU5nPT0nLCAnQmNLTXdvTEN1Zz09JywgJ3c2N0RxY09hdzVsaEhXY0cnLCAnQlNiRGdNS0R3cTNDaFhNV1ZjT1R3cnA3d29RPScsICdWaUhDdE1PT0RzSzV3NUZxZUN2Q3IzNXh3cGdVdzdBPScsICd3N1J4d3B2RG9rM0Nvc09CRTMvQ24ycE13cVV2d3JQRG5BPT0nLCAnd3JrOHc1az0nLCAnYXNPUndybz0nLCAnY3pSMHc2b2UnLCAnV2NPbHc3VT0nLCAnd3BIRHFzSy93b0U9JywgJ3dvUVp3cDdEbU1LSCcsICdjeUZPSlE9PScsICdTc09Xd3B3PSddOwooZnVuY3Rpb24oXzB4NGFmMTRhLCBfMHg1YzIyN2IpIHsKCXZhciBfMHg1OTRjZWQgPSBmdW5jdGlvbihfMHg0MWMxODEpIHsKCQkJd2hpbGUgKC0tXzB4NDFjMTgxKSB7CgkJCQlfMHg0YWYxNGFbJ3B1c2gnXShfMHg0YWYxNGFbJ3NoaWZ0J10oKSk7CgkJCX0KCQl9OwoJXzB4NTk0Y2VkKCsrXzB4NWMyMjdiKTsKfShfXzB4MmJiY2IsIDB4MWFjKSk7CnZhciBfMHg4MWJiID0gZnVuY3Rpb24oXzB4YmZhODYwLCBfMHg0ZmI0MTIpIHsKCQlfMHhiZmE4NjAgPSBfMHhiZmE4NjAgLSAweDA7CgkJdmFyIF8weDIxMGI5NSA9IF9fMHgyYmJjYltfMHhiZmE4NjBdOwoJCWlmIChfMHg4MWJiWydpbml0aWFsaXplZCddID09PSB1bmRlZmluZWQpIHsKCQkJKGZ1bmN0aW9uKCkgewoJCQkJdmFyIF8weDUyNjMzYyA9IHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnID8gd2luZG93IDogdHlwZW9mIHByb2Nlc3MgPT09ICdvYmplY3QnICYmIHR5cGVvZiByZXF1aXJlID09PSAnZnVuY3Rpb24nICYmIHR5cGVvZiBnbG9iYWwgPT09ICdvYmplY3QnID8gZ2xvYmFsIDogdGhpczsKCQkJCXZhciBfMHgyOTVjZTQgPSAnQUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5ejAxMjM0NTY3ODkrLz0nOwoJCQkJXzB4NTI2MzNjWydhdG9iJ10gfHwgKF8weDUyNjMzY1snYXRvYiddID0gZnVuY3Rpb24oXzB4NGYyMWM5KSB7CgkJCQkJdmFyIF8weDU5YzgwMiA9IFN0cmluZyhfMHg0ZjIxYzkpWydyZXBsYWNlJ10oLz0rJC8sICcnKTsKCQkJCQlmb3IgKHZhciBfMHg1MWJjMTEgPSAweDAsIF8weDM1MjM3OSwgXzB4MmU4N2NiLCBfMHgyOGQwYjAgPSAweDAsIF8weDVhNzhjNSA9ICcnOyBfMHgyZTg3Y2IgPSBfMHg1OWM4MDJbJ2NoYXJBdCddKF8weDI4ZDBiMCsrKTt+XzB4MmU4N2NiICYmIChfMHgzNTIzNzkgPSBfMHg1MWJjMTEgJSAweDQgPyBfMHgzNTIzNzkgKiAweDQwICsgXzB4MmU4N2NiIDogXzB4MmU4N2NiLCBfMHg1MWJjMTErKyAlIDB4NCkgPyBfMHg1YTc4YzUgKz0gU3RyaW5nWydmcm9tQ2hhckNvZGUnXSgweGZmICYgXzB4MzUyMzc5ID4+ICgtMHgyICogXzB4NTFiYzExICYgMHg2KSkgOiAweDApIHsKCQkJCQkJXzB4MmU4N2NiID0gXzB4Mjk1Y2U0WydpbmRleE9mJ10oXzB4MmU4N2NiKTsKCQkJCQl9CgkJCQkJcmV0dXJuIF8weDVhNzhjNTsKCQkJCX0pOwoJCQl9KCkpOwoJCQl2YXIgXzB4MTU5YTgzID0gZnVuY3Rpb24oXzB4NDNlZmE0LCBfMHgyNGY2YjMpIHsKCQkJCQl2YXIgXzB4NThlNDQ4ID0gW10sCgkJCQkJCV8weDU4MGYzNCA9IDB4MCwKCQkJCQkJXzB4MTU0MDE3LCBfMHgxNDI4MzggPSAnJywKCQkJCQkJXzB4Mjc3MTE5ID0gJyc7CgkJCQkJXzB4NDNlZmE0ID0gYXRvYihfMHg0M2VmYTQpOwoJCQkJCWZvciAodmFyIF8weDQ4YTZlZSA9IDB4MCwgXzB4MTdiYzE0ID0gXzB4NDNlZmE0WydsZW5ndGgnXTsgXzB4NDhhNmVlIDwgXzB4MTdiYzE0OyBfMHg0OGE2ZWUrKykgewoJCQkJCQlfMHgyNzcxMTkgKz0gJyUnICsgKCcwMCcgKyBfMHg0M2VmYTRbJ2NoYXJDb2RlQXQnXShfMHg0OGE2ZWUpWyd0b1N0cmluZyddKDB4MTApKVsnc2xpY2UnXSgtMHgyKTsKCQkJCQl9CgkJCQkJXzB4NDNlZmE0ID0gZGVjb2RlVVJJQ29tcG9uZW50KF8weDI3NzExOSk7CgkJCQkJZm9yICh2YXIgXzB4M2U3NjZmID0gMHgwOyBfMHgzZTc2NmYgPCAweDEwMDsgXzB4M2U3NjZmKyspIHsKCQkJCQkJXzB4NThlNDQ4W18weDNlNzY2Zl0gPSBfMHgzZTc2NmY7CgkJCQkJfQoJCQkJCWZvciAoXzB4M2U3NjZmID0gMHgwOyBfMHgzZTc2NmYgPCAweDEwMDsgXzB4M2U3NjZmKyspIHsKCQkJCQkJXzB4NTgwZjM0ID0gKF8weDU4MGYzNCArIF8weDU4ZTQ0OFtfMHgzZTc2NmZdICsgXzB4MjRmNmIzWydjaGFyQ29kZUF0J10oXzB4M2U3NjZmICUgXzB4MjRmNmIzWydsZW5ndGgnXSkpICUgMHgxMDA7CgkJCQkJCV8weDE1NDAxNyA9IF8weDU4ZTQ0OFtfMHgzZTc2NmZdOwoJCQkJCQlfMHg1OGU0NDhbXzB4M2U3NjZmXSA9IF8weDU4ZTQ0OFtfMHg1ODBmMzRdOwoJCQkJCQlfMHg1OGU0NDhbXzB4NTgwZjM0XSA9IF8weDE1NDAxNzsKCQkJCQl9CgkJCQkJXzB4M2U3NjZmID0gMHgwOwoJCQkJCV8weDU4MGYzNCA9IDB4MDsKCQkJCQlmb3IgKHZhciBfMHgxOTYyYjMgPSAweDA7IF8weDE5NjJiMyA8IF8weDQzZWZhNFsnbGVuZ3RoJ107IF8weDE5NjJiMysrKSB7CgkJCQkJCV8weDNlNzY2ZiA9IChfMHgzZTc2NmYgKyAweDEpICUgMHgxMDA7CgkJCQkJCV8weDU4MGYzNCA9IChfMHg1ODBmMzQgKyBfMHg1OGU0NDhbXzB4M2U3NjZmXSkgJSAweDEwMDsKCQkJCQkJXzB4MTU0MDE3ID0gXzB4NThlNDQ4W18weDNlNzY2Zl07CgkJCQkJCV8weDU4ZTQ0OFtfMHgzZTc2NmZdID0gXzB4NThlNDQ4W18weDU4MGYzNF07CgkJCQkJCV8weDU4ZTQ0OFtfMHg1ODBmMzRdID0gXzB4MTU0MDE3OwoJCQkJCQlfMHgxNDI4MzggKz0gU3RyaW5nWydmcm9tQ2hhckNvZGUnXShfMHg0M2VmYTRbJ2NoYXJDb2RlQXQnXShfMHgxOTYyYjMpIF4gXzB4NThlNDQ4WyhfMHg1OGU0NDhbXzB4M2U3NjZmXSArIF8weDU4ZTQ0OFtfMHg1ODBmMzRdKSAlIDB4MTAwXSk7CgkJCQkJfQoJCQkJCXJldHVybiBfMHgxNDI4Mzg7CgkJCQl9OwoJCQlfMHg4MWJiWydyYzQnXSA9IF8weDE1OWE4MzsKCQkJXzB4ODFiYlsnZGF0YSddID0ge307CgkJCV8weDgxYmJbJ2luaXRpYWxpemVkJ10gPSAhISBbXTsKCQl9CgkJdmFyIF8weDJiNzU0NiA9IF8weDgxYmJbJ2RhdGEnXVtfMHhiZmE4NjBdOwoJCWlmIChfMHgyYjc1NDYgPT09IHVuZGVmaW5lZCkgewoJCQlpZiAoXzB4ODFiYlsnb25jZSddID09PSB1bmRlZmluZWQpIHsKCQkJCV8weDgxYmJbJ29uY2UnXSA9ICEhIFtdOwoJCQl9CgkJCV8weDIxMGI5NSA9IF8weDgxYmJbJ3JjNCddKF8weDIxMGI5NSwgXzB4NGZiNDEyKTsKCQkJXzB4ODFiYlsnZGF0YSddW18weGJmYTg2MF0gPSBfMHgyMTBiOTU7CgkJfSBlbHNlIHsKCQkJXzB4MjEwYjk1ID0gXzB4MmI3NTQ2OwoJCX0KCQlyZXR1cm4gXzB4MjEwYjk1OwoJfTsKCQoJdmFyIGtleV9iYXNlID0gXzB4ODFiYignMHgyJywgJ20wMU4nKTsKCXZhciBpdl9iYXNlID0gXzB4ODFiYignMHgzJywgJ1FoQ0InKTsKCXZhciBzaWd1ID0gZnVuY3Rpb24oXzB4ODYzZGM2KSB7CgkJCXZhciBfMHhkZDkxOTIgPSBDcnlwdG9KU1tfMHg4MWJiKCcweDQnLCAnJkxTMicpXShrZXlfYmFzZSk7CgkJCXZhciBfMHhhYmIyYmYgPSBDcnlwdG9KU1tfMHg4MWJiKCcweDUnLCAnNDdCaScpXVsnVXRmOCddW18weDgxYmIoJzB4NicsICckKG0hJyldKF8weGRkOTE5Mik7CgkJCXZhciBfMHg0YTQwZWIgPSBDcnlwdG9KU1tfMHg4MWJiKCcweDcnLCAnNipqIScpXVtfMHg4MWJiKCcweDgnLCAnTHhYcScpXVtfMHg4MWJiKCcweDknLCAnJkxTMicpXShpdl9iYXNlKTsKCQkJdmFyIF8weDUyNDM0MyA9IENyeXB0b0pTWydBRVMnXVsnZW5jcnlwdCddKF8weDg2M2RjNiwgXzB4YWJiMmJmLCB7CgkJCQknaXYnOiBfMHg0YTQwZWIsCgkJCQknbW9kZSc6IENyeXB0b0pTW18weDgxYmIoJzB4YScsICd4ZnBTJyldW18weDgxYmIoJzB4YicsICc3JGRUJyldLAoJCQkJJ3BhZGRpbmcnOiBDcnlwdG9KU1tfMHg4MWJiKCcweGMnLCAna1l6SCcpXVsnWmVyb1BhZGRpbmcnXQoJCQl9KTsKCQkJcmV0dXJuIF8weDUyNDM0M1tfMHg4MWJiKCcweGQnLCAnVFI3WScpXSgpOwoJCX07Cgp2YXIgc3RyPSRmaWVsZHM7CkNvb2tpZS5zZXQoImtleSIsc3RyLmtleSx7ZXhwaXJlczoiNXMiLHBhdGg6Ii8ifSk7CkNvb2tpZS51cGRhdGUoKTsKLy9jb25zb2xlLmxvZyhDb29raWUuZ2V0KCJrZXkiKSk7Cjwvc2NyaXB0PgoKPC9ib2R5Pgo8L2h0bWw+',
    'fields' => 'dXJsPSR1cmwma2V5PSRrZXk=',
    'strtr' => 'JHVybCwka2V5',
    'cookie' => '',
    'proxy' => '',
    'val_off' => '1',
    'header' => 
    array (
      'Content-Type' => 'application/x-www-form-urlencoded',
    ),
    'add' => NULL,
    'val' => 
    array (
      'url' => 'url',
      'code' => 'code',
      'play' => 'type',
    ),
  ),
  2 => 
  array (
    'off' => '0',
    'type' => '0',
    'api' => '0',
    'match' => 'e1wkXC5wb3N0XCgiKC4rPykiLChcey4qXH0pLH0=',
    'num' => '100',
    'name' => 'PPS解析',
    'path' => 'http://jx.arpps.com/pps/?url=',
    'shell' => 'JG1kNT0kX0NPT0tJRVsibWQ1Il07IAoka2V5PSRfQ09PS0lFWyJrZXkiXTsgCg==',
    'html' => 'PGh0bWw+CjxoZWFkPgo8c2NyaXB0IHR5cGU9InRleHQvamF2YXNjcmlwdCIgc3JjPSJodHRwOi8vanguYXJwcHMuY29tL3Bwcy9ja3BsYXllci9tZDUubWluLmpzIj48L3NjcmlwdD4KPHNjcmlwdCB0eXBlPSJ0ZXh0L2phdmFzY3JpcHQiIHNyYz0iaHR0cDovL2p4LmFycHBzLmNvbS9wcHMvY2twbGF5ZXIvQXV0aENvZGUuanMiPjwvc2NyaXB0Pgo8c2NyaXB0IHR5cGU9InRleHQvamF2YXNjcmlwdCIgc3JjPSIuL2luY2x1ZGUvY29va2llLmpzIj48L3NjcmlwdD4KPC9oZWFkPgo8Ym9keT4KPHNjcmlwdD4KCnZhciBzdHI9JGZpZWxkczsKQ29va2llLnNldCgibWQ1IixzaWduKHN0ci5rZXkpLHtleHBpcmVzOiI1cyIscGF0aDoiLyJ9KTsKQ29va2llLnNldCgia2V5IixzdHIua2V5LHtleHBpcmVzOiI1cyIscGF0aDoiLyJ9KTsKQ29va2llLnVwZGF0ZSgpOwoKY29uc29sZS5sb2coc2lnbihzdHIua2V5KSk7CmNvbnNvbGUubG9nKHN0ci5rZXkpOwoKPC9zY3JpcHQ+Cgo8L2JvZHk+CjwvaHRtbD4K',
    'fields' => 'aWQ9JHVybCZtZDU9JG1kNSZrZXk9JGtleQ==',
    'strtr' => 'JHVybCwkbWQ1LCRrZXk=',
    'cookie' => '',
    'proxy' => '',
    'val_off' => '0',
    'header' => 
    array (
      'Content-Type' => 'application/x-www-form-urlencoded',
    ),
    'add' => NULL,
    'val' => 
    array (
      'url' => 'url',
    ),
  ),
);
$jx_url=array (
  0 => 'https://vip.ooosoo.com/jx/?url=',
  1 => 'https://api.azzc.cn/zy/?url=',
  2 => 'http://api.7kki.cn/api/?url=',
);
$jx_link=array (
  '视频搜索' => 'xyplay.href("so.html?url="+xyplay.url);',
);
$live_url=array (
  '解说电影' => 'xyplay.live("http://tx.hls.huya.com/huyalive/94525224-2583571962-11096357083652554752-3503038830-10057-A-0-1.m3u8");',
  '电影轮播' => 'xyplay.live("http://alhls.cdn.zhanqi.tv/zqlive/102444_ZGmRp.m3u8");',
  '陈翔六点半' => 'xyplay.live("http://tx.hls.huya.com/huyalive/94525224-2655537474-11405446604132450304-2704233350-10057-A-0-1.m3u8");',
  '许老师讲故事' => 'xyplay.live("http://tx.hls.huya.com/huyalive/28466698-2689658976-11551997339312848896-2789274534-10057-A-0-1.m3u8");',
  '成龙电影' => 'xyplay.live("http://tx.hls.huya.com/huyalive/94525224-2460685722-10568564701724147712-2789253838-10057-A-0-1.m3u8");',
  '徐峥电影' => 'xyplay.live("http://tx.hls.huya.com/huyalive/30765679-2689675828-11552069718101721088-3048991626-10057-A-0-1.m3u8");',
  '周星驰电影' => 'xyplay.live("http://tx.hls.huya.com/huyalive/94525224-2460685313-10568562945082523648-2789274524-10057-A-0-1.m3u8");',
  '周润发电影' => 'xyplay.live("http://tx.hls.huya.com/huyalive/94525224-2460685774-10568564925062447104-2789253840-10057-A-0-1.m3u8");',
  '刘德华电影' => 'xyplay.live("http://tx.hls.huya.com/huyalive/94525224-2467341872-10597152648291418112-2789274550-10057-A-0-1.m3u8");',
  '李连杰电影' => 'xyplay.live("http://tx.hls.huya.com/huyalive/94525224-2460686093-10568566295157014528-2789253848-10057-A-0-1.m3u8");',
  '洪金宝电影' => 'xyplay.live("http://tx.hls.huya.com/huyalive/29106097-2689406282-11550912026846953472-2789274558-10057-A-0-1.m3u8");',
  '林正英电影' => 'xyplay.live("http://tx.hls.huya.com/huyalive/94525224-2460686034-10568566041753944064-2789274542-10057-A-0-1.m3u8");',
  '甄子丹电影' => 'xyplay.live("http://tx.hls.huya.com/huyalive/29169025-2686219938-11537226783573147648-2847699096-10057-A-1524024759-1.m3u8");',
  '古天乐电影' => 'xyplay.live("http://tx.hls.huya.com/huyalive/29169025-2686220040-11537227221659811840-2713685416-10057-A-1524041498-1.m3u8");',
  '斯坦森电影' => 'xyplay.live("http://tx.hls.huya.com/huyalive/30765679-2554414705-10971127618396487680-3048991636-10057-A-0-1.m3u8");',
  '徐克导演' => 'xyplay.live("http://tx.hls.huya.com/huyalive/29106097-2689447148-11551087544980471808-2789253872-10057-A-1525420294-1.m3u8");',
  '王晶导演' => 'xyplay.live("http://tx.hls.huya.com/huyalive/94525224-2579683592-11079656661667807232-2847687574-10057-A-0-1.m3u8");',
  '古惑仔电影' => 'xyplay.live("http://tx.hls.huya.com/huyalive/30765679-2523417522-10837995731143360512-2777068634-10057-A-0-1.m3u8");',
  '赌博电影' => 'xyplay.live("http://tx.hls.huya.com/huyalive/29106097-2689446042-11551082794746642432-2789253870-10057-A-0-1.m3u8");',
  '科幻电影' => 'xyplay.live("http://tx.hls.huya.com/huyalive/30765679-2499070088-10733424298371842048-2789274548-10057-A-1521102596-1.m3u8");',
  '漫威电影' => 'xyplay.live("http://tx.hls.huya.com/huyalive/30765679-2504742278-10757786168918540288-3049003128-10057-A-0-1.m3u8");',
  '女神港片' => 'xyplay.live("http://tx.hls.huya.com/huyalive/30765679-2484192476-10669525441389264896-2789274564-10057-A-0-1.m3u8");',
  '怪物科幻' => 'xyplay.live("http://tx.hls.huya.com/huyalive/30765679-2478268764-10644083292078342144-2847699106-10057-A-0-1.m3u8");',
  '丧尸电影' => 'xyplay.live("http://tx.hls.huya.com/huyalive/29106097-2689286606-11550398022340837376-2789274544-10057-A-0-1.m3u8");',
  '战争电影' => 'xyplay.live("http://tx.hls.huya.com/huyalive/28466698-2689659358-11551998979990355968-2789274580-10057-A-0-1.m3u8");',
  '犯罪悬疑' => 'xyplay.live("http://tx.hls.huya.com/huyalive/30765679-2480288304-10652757150331305984-2789274538-10057-A-1511757260-1.m3u8");',
  '好莱坞电影' => 'xyplay.live("http://tx.hls.huya.com/huyalive/30765679-2484192572-10669525853706125312-2847687498-10057-A-1521100607-1.m3u8");',
  '灾难电影' => 'xyplay.live("http://tx.hls.huya.com/huyalive/29359996-2689475864-11551210879261343744-2847699104-10057-A-1525430092-1.m3u8");',
  '真实改编' => 'xyplay.live("http://tx.hls.huya.com/huyalive/30765679-2554414680-10971127511022305280-3048991634-10057-A-0-1.m3u8");',
  '惊悚电影' => 'xyplay.live("http://tx.hls.huya.com/huyalive/29106097-2689447600-11551089486305689600-2789274568-10057-A-1525420695-1.m3u8");',
  '复仇犯罪' => 'xyplay.live("http://tx.hls.huya.com/huyalive/28466698-2689661530-11552008308659322880-3049003102-10057-A-0-1.m3u8");',
  'CCTV1' => 'xyplay.live("http://cctvtxyh5c.liveplay.myqcloud.com/live/cctv1_2/index.m3u8?contentid=2820180516001&uid=default#index.m3u8");',
  'CCTV2' => 'xyplay.live("http://cctvtxyh5c.liveplay.myqcloud.com/live/cctv2_2/index.m3u8?contentid=2820180516001&uid=default#index.m3u8");',
  'CCTV3' => 'xyplay.live("http://cctvtxyh5c.liveplay.myqcloud.com/live/cctv3_2/index.m3u8?contentid=2820180516001&uid=default#index.m3u8");',
  'CCTV4' => 'xyplay.live("http://cctvtxyh5c.liveplay.myqcloud.com/live/cctv4_2/index.m3u8?contentid=2820180516001&uid=default#index.m3u8");',
  'CCTV5' => 'xyplay.live("http://cctvtxyh5c.liveplay.myqcloud.com/live/cctv5_2/index.m3u8?contentid=2820180516001&uid=default#index.m3u8");',
  'CCTV5+' => 'xyplay.live("http://cctvtxyh5c.liveplay.myqcloud.com/live/cctv5plus_2/index.m3u8?contentid=2820180516001&uid=default#index.m3u8");',
  'CCTV6' => 'xyplay.live("http://cctvtxyh5c.liveplay.myqcloud.com/live/cctv6_2/index.m3u8?contentid=2820180516001&uid=default#index.m3u8");',
  'CCTV7' => 'xyplay.live("http://cctvtxyh5c.liveplay.myqcloud.com/live/cctv7_2/index.m3u8?contentid=2820180516001&uid=default#index.m3u8");',
  'CCTV8' => 'xyplay.live("http://cctvtxyh5c.liveplay.myqcloud.com/live/cctv8_2/index.m3u8?contentid=2820180516001&uid=default#index.m3u8");',
  'CCTV9' => 'xyplay.live("http://cctvcnch5c.v.wscdns.com/live/cctvjilu_2/index.m3u8?contentid=2820180516001&uid=default#index.m3u8");',
  'CCTV10' => 'xyplay.live("http://cctvtxyh5c.liveplay.myqcloud.com/live/cctv10_2/index.m3u8?contentid=2820180516001&uid=default#index.m3u8");',
  'CCTV11' => 'xyplay.live("http://cctvtxyh5c.liveplay.myqcloud.com/live/cctv11_2/index.m3u8?contentid=2820180516001&uid=default#index.m3u8");',
  'CCTV12' => 'xyplay.live("http://cctvtxyh5c.liveplay.myqcloud.com/live/cctv12_2/index.m3u8?contentid=2820180516001&uid=default#index.m3u8");',
  'CCTV13' => 'xyplay.live("http://cctvtxyh5c.liveplay.myqcloud.com/live/cctv13_2/index.m3u8?contentid=2820180516001&uid=default#index.m3u8");',
  'CCTV14' => 'xyplay.live("http://cctvtxyh5c.liveplay.myqcloud.com/live/cctvchild_2/index.m3u8?contentid=2820180516001&uid=default#index.m3u8");',
  'CCTV15' => 'xyplay.live("http://cctvtxyh5c.liveplay.myqcloud.com/live/cctv15_2/index.m3u8?contentid=2820180516001&uid=default#index.m3u8");',
  '新华社中文' => 'xyplay.live("http://live.xinhuashixun.com/live/chn01/desc.m3u8")',
  '环球电视台' => 'xyplay.live("http://live-cdn.xzxwhcb.com/hls/r86am856.m3u8")',
  '凤凰卫视电影台' => 'xyplay.live("http://live.italkdd.com/cds160/hls/channel003/channel003_2000.m3u8")',
  '直播秀' => 'xyplay.live("http://dlhls.live.cnlive.com:1935/cdn/liveshow/playlist.m3u8");',
  '香港直播新聞' => 'xyplay.live("http://media.fantv.hk/m3u8/archive/channel2_stream1.m3u8");',
  '台视新闻' => 'xyplay.live("http://live.italkdd.com/cds160/hls/channel006/channel006_2000.m3u8");',
  '民视新闻台' => 'xyplay.live("http://210.61.56.23/hls/ftvtv/index.m3u8");',
  '星卫电影台' => 'xyplay.live("http://dlhls.cdn.zhanqi.tv/zqlive/35349_iXsXw.m3u8");',
  '战旗电影' => 'xyplay.live("http://dlhls.cdn.zhanqi.tv/zqlive/7032_0s2qn.m3u8");',
  'TVB翡翠财经' => 'xyplay.live("http://e1.vdowowza.vip.hk1.tvb.com/tvblive/smil:mobilehd_financeintl.smil/chunklist_w1412641159_b448000.m3u8");',
  '韩国EBS2' => 'xyplay.live("http://ebsonair.ebs.co.kr:1935/ebs2familypc/familypc1m/playlist.m3u8");',
  '乌克兰JTV' => 'xyplay.live("http://jtvmedia.jtv.com:1975/live/live6/lihattv.m3u8");',
  '无线财经资讯' => 'xyplay.xyplay("http://e1.vdowowza.vip.hk1.tvb.com/tvblive/smil:mobilehd_financeintl.smil/chunklist_w1286040896_b224000.m3u8");',
  '功夫台' => 'xyplay.live("http://weblive.hebtv.com/live/Asianaction/index.m3u8");',
  'CINEMAX' => 'xyplay.live("http://iptv-nl3-qscdn.hdflixtv.com/VN-Cinemax/tracks-v1a1/mono.m3u8");',
);
$play=array (
  'off' => 
  array (
    'yun' => '1',
    'link' => '1',
    'live' => '1',
    'help' => '1',
    'debug' => '0',
    'log' => '0',
    'autolist' => '0',
    'ckplay' => '1',
    'jmp' => '0',
    'autoline' => '0',
    'autoflag' => '0',
    'mylink' => '1',
    'lshttps' => '0',
  ),
  'line' => 
  array (
    'pc' => 
    array (
      'line' => '1',
      'adtime' => '0',
      'adPage' => 'source/plug/pc.html',
    ),
    'wap' => 
    array (
      'line' => '1',
      'adtime' => '0',
      'adPage' => 'source/plug/pc.html',
    ),
    'all' => 
    array (
      'autoline' => 
      array (
        'off' => '0',
        'val' => 
        array (
          'iqiyi.com' => '2',
          'v.qq.com' => '3',
        ),
      ),
    ),
  ),
  'play' => 
  array (
    'pc' => 
    array (
      'player' => 'dplayer',
      'autoplay' => '1',
    ),
    'wap' => 
    array (
      'player' => 'dplayer',
      'autoplay' => '0',
    ),
    'all' => 
    array (
      'autoline' => 
      array (
        'off' => '0',
        'val' => 
        array (
          'iqiyi.com' => 'ckplayerx',
          'v.qq.com' => 'dplayer',
        ),
      ),
      'headtime' => '0',
      'endtime' => '0',
    ),
  ),
  'all' => 
  array (
    'AppName' => 'xysoft|xyplayer',
    'ver' => '智能视频解析  ',
    'by' => '智能解析 版权所有',
    'info' => '如果播放失败，请切换不同线路!云播放已支持缓存秒加载，欢迎使用!',
    'decode' => 'ICAvLyBsb2NhdGlvbi5ocmVmPSJodHRwOi8vbm9oYWNrcy5jbiI7ICAvL+i3s+i9rOe9keermQp4eXBsYXkuZWNobygiPGJyPjxicj48YnI+5qOA5rWL5Yiw6Z2e5rOV6LCD6K+VLOivt+WFs+mXreWQjuWIt+aWsOmHjeivlSEiKTsgIC8v55So5oi356qX5Y+j5pi+56S65L+h5oGvCnNldEludGVydmFsKCJkZWJ1Z2dlcjtjb25zb2xlLmxvZyhcJ+ivt+WLv+mdnuazleiwg+ivlSzotK3kubDor7fogZTns7tRUToyMzQ1MzE2MVwnKTsiKTsgICAgICAvL+iwg+ivleeql+WPo+aYvuekuuS/oeaBrwk=',
    'link_info' => '服务器正在解析中,请稍后....',
    'yun_info' => '服务器正在解析中,请稍后....',
  ),
  'style' => 
  array (
    'logo_show' => '1',
    'line_show' => '1',
    'list_show' => '1',
    'flaglist_show' => '1',
    'playlist_show' => '1',
    'line_style' => 'color:#2693FF;border:1px solid #2693FF;',
    'line_hover' => 'color:#FFF;background-color:#2693FF;',
    'line_on' => 'color:#FFF;background-color:#2693FF;',
    'play_style' => 'color:#FFF;border:1px solid #2693FF;',
    'play_hover' => 'color:#FFF;background-color:#2693FF;',
    'play_on' => 'color:#FFF;background-color:#2693FF;',
    'off' => NULL,
  ),
  'match' => 
  array (
    'yunflag' => '',
    'video' => '',
    'urljmp' => 'BGM->http://api.jp255.com/api/?url=',
    'urlurl' => '/share/',
    'urlflag' => 'url|yun|ziyuan',
    'playflag' => 'ogg|mp4|webm|m3u8|ck',
    'flagjmp' => 'fooyun->http://www.fooyun.xyz/share/',
  ),
  'define' => 
  array (
  ),
);
